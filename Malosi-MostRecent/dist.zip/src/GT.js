const headerWord = document.getElementById('headerWord');

headerWord.innerHTML = "peeep game";


try {
    const { MongoClient } = require('/mongodb/mongodb');
    headerWord.innerHTML = "yes";
} catch (error) {
    headerWord.innerHTML = "askies";
}

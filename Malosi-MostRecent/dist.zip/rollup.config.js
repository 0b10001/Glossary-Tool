export default{
    input: 'src/GT.js',
    output: {
      file: 'dist/rollup-bundle.js',
      format: 'umd'
    }
}